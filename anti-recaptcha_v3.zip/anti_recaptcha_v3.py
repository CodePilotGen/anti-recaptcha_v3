import os

import requests
from ibm_watson import SpeechToTextV1
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator

import cv2
import numpy as np
import pyautogui
import time
import win32clipboard
import webbrowser
import pyperclip

success = 0
apikey = '6yqI4Ag-oUqMW_GZ02KEgwnWCPXqpUBO3Kt6ZoZhHBa5'
url = 'https://api.us-south.speech-to-text.watson.cloud.ibm.com/instances/cbe70cfa-8d0a-42fb-a31a-703be7037637'
delayTime = 2
audioToTextDelay = 10
filename = '1.mp3'

byPassUrl = 'http://scw.pjn.gov.ar/scw/home.seam'
googleIBMLink = 'https://speech-to-text-demo.ng.bluemix.net/'

webbrowser.register('chrome', None, webbrowser.BackgroundBrowser("C://Program Files//Google//Chrome//Application//chrome.exe"))
webbrowser.get('chrome').open(byPassUrl)


def audioToText(mp3Path):
    authenticator = IAMAuthenticator(apikey)
    stt = SpeechToTextV1(authenticator=authenticator)
    stt.set_service_url(url)

    with open(mp3Path, 'rb') as f:
        try:
            res = stt.recognize(audio=f, content_type='audio/mp3', model='es-ES_BroadbandModel', continuous=True).get_result()
            text = res['results'][0]['alternatives'][0]['transcript']
        except:
            text = []
    
    return text
def saveFile(content,filename):
    with open(filename, "wb") as handle:
        for data in content.iter_content():
            handle.write(data)

def clickItem(subimage, rl='left'):
    coords = []

    pic = pyautogui.screenshot()    #taking screenshot
    pic.save('main.jpg')            #saving screenshot

    img_rgb = cv2.imread('main.jpg')
    img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)               ###beginning template matching###
    template = cv2.imread(subimage,0)                                  #
    # w, h = template.shape[::-1]                                         #

    res = cv2.matchTemplate(img_gray,template,cv2.TM_CCOEFF_NORMED)
    threshold = 0.8
    loc = np.where( res >= threshold)

    for pt in zip(*loc[::-1]):
        coords.append(pt[0])        #storing upper left coordinates of reCAPTCHA box
        coords.append(pt[1])


    if len(coords)!= 0 :
        reCAPTCHA_box_x_bias = 25
        reCAPTCHA_box_y_bias = 20

        coords[0] = coords[0] + reCAPTCHA_box_x_bias
        coords[1] = coords[1] + reCAPTCHA_box_y_bias

        pyautogui.moveTo(1, 1, duration = 0)
        pyautogui.moveTo(coords[0], coords[1], duration = 0.12)

        if(rl == 'left'):
            pyautogui.click()
        else:
            pyautogui.rightClick()


    else :
        print ('-> reCAPTCHA box not found!')
def lifecycle():
    time.sleep(5)
    clickItem('subimages/ctcha_check.jpg')
    time.sleep(2)
    clickItem('subimages/reshiba.jpg')
    time.sleep(2)
    clickItem('subimages/download_btn.jpg', rl='right')
    time.sleep(1)
    clickItem('subimages/copy_link_as.jpg')
    time.sleep(1)
    win32clipboard.OpenClipboard()
    href = win32clipboard.GetClipboardData()
    win32clipboard.CloseClipboard()
    # print(data)
    response = requests.get(href, stream=True)
    
    saveFile(response,filename)
    response = audioToText(os.getcwd() + '/' + filename)
    print(response)
    if(response == []):
        clickItem('subimages/chrome_refresh.jpg')
        return
    clickItem('subimages/input_box.jpg')
    pyperclip.copy(response)
    time.sleep(0.5)
    pyautogui.hotkey('ctrl', 'v')
    pyautogui.press('enter')

    time.sleep(2)

    clickItem('subimages/chrome_refresh.jpg')

    return
if __name__ == "__main__":

    refresh_num = 10
    while refresh_num > 0:
        lifecycle()
        refresh_num -= 1

    